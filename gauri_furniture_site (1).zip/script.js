// Example: Alert when user visits site
window.onload = () => {
  console.log("गौरी फर्नीचर एण्ड इलेक्ट्रॉनिक्स वेबसाइट पर आपका स्वागत है!");
};
